Dataloader
===========
There are two ways to load data.

.. autoclass:: simuleval.data.dataloader.GenericDataloader