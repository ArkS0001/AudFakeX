Installation
============

From pip
--------

.. code-block:: bash

    pip install simuleval


From source
-----------

.. code-block:: bash

    git clone https://github.com/facebookresearch/SimulEval.git
    cd SimulEval
    pip install -e .


