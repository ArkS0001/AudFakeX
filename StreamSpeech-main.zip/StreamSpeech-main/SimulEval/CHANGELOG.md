1.0.0 (September 25, 2020)

* Initial release.

1.0.1 (February 8, 2021)

* Change CLI command
    * Change `simuleval-server` to `simuleval --server-only`
    * Change `simuleval-client` to `simuleval --client-only`
* Fix some typos
