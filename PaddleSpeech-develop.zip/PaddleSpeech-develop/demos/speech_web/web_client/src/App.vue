<script setup>
import Experience from './components/Experience.vue'
import Header from './components/Content/Header/Header.vue'
</script>

<template>
  <div class="app">
    <Header></Header>
    <Experience></Experience>
  </div>


</template>

<style style="less">
.app {
  background: url("assets/image/在线体验-背景@2x.png") no-repeat;
};
</style>
