#!/bin/bash

paddlespeech_server start --config_file ./conf/application.yaml &> server.log &
