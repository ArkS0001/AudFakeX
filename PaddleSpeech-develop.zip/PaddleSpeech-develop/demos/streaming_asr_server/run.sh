# start the streaming asr service
paddlespeech_server start --config_file ./conf/ws_conformer_application.yaml