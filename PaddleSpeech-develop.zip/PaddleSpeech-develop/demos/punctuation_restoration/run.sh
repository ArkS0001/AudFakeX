#!/bin/bash

paddlespeech text --input 今天的天气真好啊你下午有空吗我想约你一起去吃饭
