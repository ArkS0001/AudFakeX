---
name: "\U0001F914 Ask a Question"
about: I want to ask a question.
title: ''
labels: Question
assignees: ''

---

## General Question

<!--
Before asking a question, make sure you have:
- Baidu/Google your question.
- Searched open and closed [GitHub issues](https://github.com/PaddlePaddle/PaddleSpeech/issues?q=is%3Aissue)
- Read the documentation:
  - [Readme](https://github.com/PaddlePaddle/PaddleSpeech)
  - [Doc](https://paddlespeech.readthedocs.io/)
-->
