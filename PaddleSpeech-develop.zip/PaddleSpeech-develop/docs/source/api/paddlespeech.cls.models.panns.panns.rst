paddlespeech.cls.models.panns.panns module
==========================================

.. automodule:: paddlespeech.cls.models.panns.panns
   :members:
   :undoc-members:
   :show-inheritance:
