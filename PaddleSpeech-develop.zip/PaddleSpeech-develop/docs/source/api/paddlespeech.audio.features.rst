paddlespeech.audio.features package
===================================

.. automodule:: paddlespeech.audio.features
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.features.layers
