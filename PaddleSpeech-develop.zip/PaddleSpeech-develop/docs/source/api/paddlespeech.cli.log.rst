paddlespeech.cli.log module
===========================

.. automodule:: paddlespeech.cli.log
   :members:
   :undoc-members:
   :show-inheritance:
