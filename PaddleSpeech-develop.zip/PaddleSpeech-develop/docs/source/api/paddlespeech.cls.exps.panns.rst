paddlespeech.cls.exps.panns package
===================================

.. automodule:: paddlespeech.cls.exps.panns
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cls.exps.panns.deploy

Submodules
----------

.. toctree::
   :maxdepth: 4
