paddlespeech.s2t.exps.deepspeech2.bin.deploy package
====================================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin.deploy
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.exps.deepspeech2.bin.deploy.runtime
   paddlespeech.s2t.exps.deepspeech2.bin.deploy.server
