paddlespeech.cli.kws package
============================

.. automodule:: paddlespeech.cli.kws
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.kws.infer
