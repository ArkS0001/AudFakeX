paddlespeech.s2t.decoders.scorers.ctc module
============================================

.. automodule:: paddlespeech.s2t.decoders.scorers.ctc
   :members:
   :undoc-members:
   :show-inheritance:
