paddlespeech.resource.pretrained\_models module
===============================================

.. automodule:: paddlespeech.resource.pretrained_models
   :members:
   :undoc-members:
   :show-inheritance:
