paddlespeech.s2t.decoders.scorers package
=========================================

.. automodule:: paddlespeech.s2t.decoders.scorers
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.decoders.scorers.ctc
   paddlespeech.s2t.decoders.scorers.ctc_prefix_score
   paddlespeech.s2t.decoders.scorers.length_bonus
   paddlespeech.s2t.decoders.scorers.scorer_interface
