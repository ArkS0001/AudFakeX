paddlespeech.cli.text package
=============================

.. automodule:: paddlespeech.cli.text
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.text.infer
