paddlespeech.cli.cls.infer module
=================================

.. automodule:: paddlespeech.cli.cls.infer
   :members:
   :undoc-members:
   :show-inheritance:
