paddlespeech.audio.streamdata.gopen module
==========================================

.. automodule:: paddlespeech.audio.streamdata.gopen
   :members:
   :undoc-members:
   :show-inheritance:
