paddlespeech.audio.text.text\_featurizer module
===============================================

.. automodule:: paddlespeech.audio.text.text_featurizer
   :members:
   :undoc-members:
   :show-inheritance:
