paddlespeech.cli.utils module
=============================

.. automodule:: paddlespeech.cli.utils
   :members:
   :undoc-members:
   :show-inheritance:
