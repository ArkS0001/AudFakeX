paddlespeech.resource.resource module
=====================================

.. automodule:: paddlespeech.resource.resource
   :members:
   :undoc-members:
   :show-inheritance:
