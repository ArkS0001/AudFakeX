paddlespeech.audio.streamdata.handlers module
=============================================

.. automodule:: paddlespeech.audio.streamdata.handlers
   :members:
   :undoc-members:
   :show-inheritance:
