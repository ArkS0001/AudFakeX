paddlespeech.cls.models package
===============================

.. automodule:: paddlespeech.cls.models
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cls.models.panns
