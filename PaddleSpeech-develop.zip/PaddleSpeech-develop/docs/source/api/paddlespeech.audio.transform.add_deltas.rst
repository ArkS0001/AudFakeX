paddlespeech.audio.transform.add\_deltas module
===============================================

.. automodule:: paddlespeech.audio.transform.add_deltas
   :members:
   :undoc-members:
   :show-inheritance:
