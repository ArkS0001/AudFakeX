paddlespeech.resource package
=============================

.. automodule:: paddlespeech.resource
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.resource.model_alias
   paddlespeech.resource.pretrained_models
   paddlespeech.resource.resource
