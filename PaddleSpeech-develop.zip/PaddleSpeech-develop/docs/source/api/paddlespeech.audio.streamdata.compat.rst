paddlespeech.audio.streamdata.compat module
===========================================

.. automodule:: paddlespeech.audio.streamdata.compat
   :members:
   :undoc-members:
   :show-inheritance:
