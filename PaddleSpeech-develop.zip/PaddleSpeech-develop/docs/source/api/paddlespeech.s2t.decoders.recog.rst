paddlespeech.s2t.decoders.recog module
======================================

.. automodule:: paddlespeech.s2t.decoders.recog
   :members:
   :undoc-members:
   :show-inheritance:
