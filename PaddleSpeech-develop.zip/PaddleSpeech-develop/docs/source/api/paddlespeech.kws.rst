paddlespeech.kws package
========================

.. automodule:: paddlespeech.kws
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.kws.exps
   paddlespeech.kws.models
