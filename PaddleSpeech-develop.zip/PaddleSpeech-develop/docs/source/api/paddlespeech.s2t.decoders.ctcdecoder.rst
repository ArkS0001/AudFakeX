paddlespeech.s2t.decoders.ctcdecoder package
============================================

.. automodule:: paddlespeech.s2t.decoders.ctcdecoder
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.decoders.ctcdecoder.decoders_deprecated
   paddlespeech.s2t.decoders.ctcdecoder.swig_wrapper
