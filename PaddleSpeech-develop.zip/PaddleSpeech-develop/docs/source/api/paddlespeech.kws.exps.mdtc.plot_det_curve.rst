paddlespeech.kws.exps.mdtc.plot\_det\_curve module
==================================================

.. automodule:: paddlespeech.kws.exps.mdtc.plot_det_curve
   :members:
   :undoc-members:
   :show-inheritance:
