paddlespeech.audio package
==========================

.. automodule:: paddlespeech.audio
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.features
   paddlespeech.audio.functional
   paddlespeech.audio.io
   paddlespeech.audio.kaldi
   paddlespeech.audio.metric
   paddlespeech.audio.sox_effects
   paddlespeech.audio.streamdata
   paddlespeech.audio.text
   paddlespeech.audio.transform
   paddlespeech.audio.utils
