paddlespeech.audio.utils.download module
========================================

.. automodule:: paddlespeech.audio.utils.download
   :members:
   :undoc-members:
   :show-inheritance:
