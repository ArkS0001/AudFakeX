paddlespeech.cli.vector package
===============================

.. automodule:: paddlespeech.cli.vector
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.vector.infer
