paddlespeech.s2t.exps.deepspeech2.bin package
=============================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.exps.deepspeech2.bin.deploy

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.exps.deepspeech2.bin.export
   paddlespeech.s2t.exps.deepspeech2.bin.test
   paddlespeech.s2t.exps.deepspeech2.bin.test_export
   paddlespeech.s2t.exps.deepspeech2.bin.test_wav
   paddlespeech.s2t.exps.deepspeech2.bin.train
