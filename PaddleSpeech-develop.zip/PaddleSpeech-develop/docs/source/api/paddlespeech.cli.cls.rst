paddlespeech.cli.cls package
============================

.. automodule:: paddlespeech.cli.cls
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.cls.infer
