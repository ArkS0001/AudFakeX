paddlespeech.cli.st.infer module
================================

.. automodule:: paddlespeech.cli.st.infer
   :members:
   :undoc-members:
   :show-inheritance:
