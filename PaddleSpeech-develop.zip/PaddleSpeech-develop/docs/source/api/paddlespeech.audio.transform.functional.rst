paddlespeech.audio.transform.functional module
==============================================

.. automodule:: paddlespeech.audio.transform.functional
   :members:
   :undoc-members:
   :show-inheritance:
