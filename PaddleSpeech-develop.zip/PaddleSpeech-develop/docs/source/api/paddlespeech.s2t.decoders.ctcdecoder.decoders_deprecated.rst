paddlespeech.s2t.decoders.ctcdecoder.decoders\_deprecated module
================================================================

.. automodule:: paddlespeech.s2t.decoders.ctcdecoder.decoders_deprecated
   :members:
   :undoc-members:
   :show-inheritance:
