paddlespeech.audio.transform.perturb module
===========================================

.. automodule:: paddlespeech.audio.transform.perturb
   :members:
   :undoc-members:
   :show-inheritance:
