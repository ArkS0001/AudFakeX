paddlespeech.audio.streamdata.pipeline module
=============================================

.. automodule:: paddlespeech.audio.streamdata.pipeline
   :members:
   :undoc-members:
   :show-inheritance:
