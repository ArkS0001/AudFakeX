paddlespeech.cli.vector.infer module
====================================

.. automodule:: paddlespeech.cli.vector.infer
   :members:
   :undoc-members:
   :show-inheritance:
