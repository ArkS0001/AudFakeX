paddlespeech.kws.exps.mdtc.score module
=======================================

.. automodule:: paddlespeech.kws.exps.mdtc.score
   :members:
   :undoc-members:
   :show-inheritance:
