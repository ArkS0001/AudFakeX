paddlespeech.kws.exps.mdtc.compute\_det module
==============================================

.. automodule:: paddlespeech.kws.exps.mdtc.compute_det
   :members:
   :undoc-members:
   :show-inheritance:
