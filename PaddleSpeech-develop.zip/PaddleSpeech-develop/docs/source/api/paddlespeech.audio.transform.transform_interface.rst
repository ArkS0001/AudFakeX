paddlespeech.audio.transform.transform\_interface module
========================================================

.. automodule:: paddlespeech.audio.transform.transform_interface
   :members:
   :undoc-members:
   :show-inheritance:
