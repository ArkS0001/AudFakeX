paddlespeech.cli.tts package
============================

.. automodule:: paddlespeech.cli.tts
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.tts.infer
