paddlespeech.audio.transform.channel\_selector module
=====================================================

.. automodule:: paddlespeech.audio.transform.channel_selector
   :members:
   :undoc-members:
   :show-inheritance:
