paddlespeech.kws.exps.mdtc.train module
=======================================

.. automodule:: paddlespeech.kws.exps.mdtc.train
   :members:
   :undoc-members:
   :show-inheritance:
