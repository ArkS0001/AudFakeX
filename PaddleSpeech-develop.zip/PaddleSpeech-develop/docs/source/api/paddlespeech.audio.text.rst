paddlespeech.audio.text package
===============================

.. automodule:: paddlespeech.audio.text
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.text.text_featurizer
   paddlespeech.audio.text.utility
