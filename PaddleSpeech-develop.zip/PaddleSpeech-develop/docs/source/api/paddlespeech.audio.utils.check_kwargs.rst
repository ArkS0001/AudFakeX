paddlespeech.audio.utils.check\_kwargs module
=============================================

.. automodule:: paddlespeech.audio.utils.check_kwargs
   :members:
   :undoc-members:
   :show-inheritance:
