paddlespeech.kws.exps package
=============================

.. automodule:: paddlespeech.kws.exps
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.kws.exps.mdtc
