paddlespeech.audio.streamdata package
=====================================

.. automodule:: paddlespeech.audio.streamdata
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.streamdata.autodecode
   paddlespeech.audio.streamdata.cache
   paddlespeech.audio.streamdata.compat
   paddlespeech.audio.streamdata.extradatasets
   paddlespeech.audio.streamdata.filters
   paddlespeech.audio.streamdata.gopen
   paddlespeech.audio.streamdata.handlers
   paddlespeech.audio.streamdata.mix
   paddlespeech.audio.streamdata.paddle_utils
   paddlespeech.audio.streamdata.pipeline
   paddlespeech.audio.streamdata.shardlists
   paddlespeech.audio.streamdata.tariterators
   paddlespeech.audio.streamdata.utils
   paddlespeech.audio.streamdata.writer
