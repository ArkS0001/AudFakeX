paddlespeech.audio.utils.tensor\_utils module
=============================================

.. automodule:: paddlespeech.audio.utils.tensor_utils
   :members:
   :undoc-members:
   :show-inheritance:
