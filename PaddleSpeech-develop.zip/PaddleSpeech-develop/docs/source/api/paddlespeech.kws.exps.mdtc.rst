paddlespeech.kws.exps.mdtc package
==================================

.. automodule:: paddlespeech.kws.exps.mdtc
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.kws.exps.mdtc.collate
   paddlespeech.kws.exps.mdtc.compute_det
   paddlespeech.kws.exps.mdtc.score
   paddlespeech.kws.exps.mdtc.train
