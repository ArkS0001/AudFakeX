paddlespeech.s2t.decoders.beam\_search.batch\_beam\_search module
=================================================================

.. automodule:: paddlespeech.s2t.decoders.beam_search.batch_beam_search
   :members:
   :undoc-members:
   :show-inheritance:
