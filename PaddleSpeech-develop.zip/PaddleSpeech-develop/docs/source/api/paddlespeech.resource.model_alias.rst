paddlespeech.resource.model\_alias module
=========================================

.. automodule:: paddlespeech.resource.model_alias
   :members:
   :undoc-members:
   :show-inheritance:
