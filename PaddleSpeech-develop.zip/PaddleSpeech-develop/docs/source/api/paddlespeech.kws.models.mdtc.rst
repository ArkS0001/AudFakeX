paddlespeech.kws.models.mdtc module
===================================

.. automodule:: paddlespeech.kws.models.mdtc
   :members:
   :undoc-members:
   :show-inheritance:
