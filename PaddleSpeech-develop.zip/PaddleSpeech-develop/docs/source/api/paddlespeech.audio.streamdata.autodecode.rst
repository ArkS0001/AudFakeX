paddlespeech.audio.streamdata.autodecode module
===============================================

.. automodule:: paddlespeech.audio.streamdata.autodecode
   :members:
   :undoc-members:
   :show-inheritance:
