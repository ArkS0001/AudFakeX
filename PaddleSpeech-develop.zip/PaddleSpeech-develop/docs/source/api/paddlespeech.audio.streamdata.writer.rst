paddlespeech.audio.streamdata.writer module
===========================================

.. automodule:: paddlespeech.audio.streamdata.writer
   :members:
   :undoc-members:
   :show-inheritance:
