paddlespeech.s2t.exps.deepspeech2.bin.test\_wav module
======================================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin.test_wav
   :members:
   :undoc-members:
   :show-inheritance:
