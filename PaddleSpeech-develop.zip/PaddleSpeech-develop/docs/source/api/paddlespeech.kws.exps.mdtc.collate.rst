paddlespeech.kws.exps.mdtc.collate module
=========================================

.. automodule:: paddlespeech.kws.exps.mdtc.collate
   :members:
   :undoc-members:
   :show-inheritance:
