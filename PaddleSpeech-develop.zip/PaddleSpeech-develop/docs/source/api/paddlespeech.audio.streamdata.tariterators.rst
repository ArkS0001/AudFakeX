paddlespeech.audio.streamdata.tariterators module
=================================================

.. automodule:: paddlespeech.audio.streamdata.tariterators
   :members:
   :undoc-members:
   :show-inheritance:
