paddlespeech.audio.streamdata.extradatasets module
==================================================

.. automodule:: paddlespeech.audio.streamdata.extradatasets
   :members:
   :undoc-members:
   :show-inheritance:
