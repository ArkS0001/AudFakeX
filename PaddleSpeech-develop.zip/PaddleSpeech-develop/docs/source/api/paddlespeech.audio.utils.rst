paddlespeech.audio.utils package
================================

.. automodule:: paddlespeech.audio.utils
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.utils.check_kwargs
   paddlespeech.audio.utils.download
   paddlespeech.audio.utils.dynamic_import
   paddlespeech.audio.utils.error
   paddlespeech.audio.utils.log
   paddlespeech.audio.utils.numeric
   paddlespeech.audio.utils.sox_utils
   paddlespeech.audio.utils.tensor_utils
   paddlespeech.audio.utils.time
