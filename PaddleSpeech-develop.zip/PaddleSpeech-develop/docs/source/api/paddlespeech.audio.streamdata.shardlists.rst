paddlespeech.audio.streamdata.shardlists module
===============================================

.. automodule:: paddlespeech.audio.streamdata.shardlists
   :members:
   :undoc-members:
   :show-inheritance:
