paddlespeech.cli.asr package
============================

.. automodule:: paddlespeech.cli.asr
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cli.asr.infer
