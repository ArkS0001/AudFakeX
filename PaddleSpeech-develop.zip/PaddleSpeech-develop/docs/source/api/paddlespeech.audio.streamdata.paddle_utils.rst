paddlespeech.audio.streamdata.paddle\_utils module
==================================================

.. automodule:: paddlespeech.audio.streamdata.paddle_utils
   :members:
   :undoc-members:
   :show-inheritance:
