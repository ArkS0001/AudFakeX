paddlespeech.s2t.exps.deepspeech2.bin.test\_export module
=========================================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin.test_export
   :members:
   :undoc-members:
   :show-inheritance:
