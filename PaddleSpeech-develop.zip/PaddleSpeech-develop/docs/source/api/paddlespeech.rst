paddlespeech package
====================

.. automodule:: paddlespeech
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio
   paddlespeech.cli
   paddlespeech.cls
   paddlespeech.kws
   paddlespeech.resource
   paddlespeech.s2t
   paddlespeech.server
   paddlespeech.t2s
   paddlespeech.text
   paddlespeech.utils
   paddlespeech.vector

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.version
