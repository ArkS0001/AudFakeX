paddlespeech.audio.transform.cmvn module
========================================

.. automodule:: paddlespeech.audio.transform.cmvn
   :members:
   :undoc-members:
   :show-inheritance:
