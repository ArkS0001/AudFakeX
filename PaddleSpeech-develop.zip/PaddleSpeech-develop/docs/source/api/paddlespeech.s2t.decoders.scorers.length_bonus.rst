paddlespeech.s2t.decoders.scorers.length\_bonus module
======================================================

.. automodule:: paddlespeech.s2t.decoders.scorers.length_bonus
   :members:
   :undoc-members:
   :show-inheritance:
