paddlespeech.audio.utils.time module
====================================

.. automodule:: paddlespeech.audio.utils.time
   :members:
   :undoc-members:
   :show-inheritance:
