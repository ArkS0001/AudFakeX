paddlespeech.s2t.exps.deepspeech2.bin.test module
=================================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin.test
   :members:
   :undoc-members:
   :show-inheritance:
