paddlespeech.cls.models.panns.classifier module
===============================================

.. automodule:: paddlespeech.cls.models.panns.classifier
   :members:
   :undoc-members:
   :show-inheritance:
