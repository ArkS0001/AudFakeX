paddlespeech.cli.kws.infer module
=================================

.. automodule:: paddlespeech.cli.kws.infer
   :members:
   :undoc-members:
   :show-inheritance:
