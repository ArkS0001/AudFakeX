paddlespeech.s2t.decoders.scorers.ctc\_prefix\_score module
===========================================================

.. automodule:: paddlespeech.s2t.decoders.scorers.ctc_prefix_score
   :members:
   :undoc-members:
   :show-inheritance:
