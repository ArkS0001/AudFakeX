paddlespeech.audio.transform.spectrogram module
===============================================

.. automodule:: paddlespeech.audio.transform.spectrogram
   :members:
   :undoc-members:
   :show-inheritance:
