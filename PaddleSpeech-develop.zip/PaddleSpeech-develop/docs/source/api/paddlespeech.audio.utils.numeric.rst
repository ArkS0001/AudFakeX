paddlespeech.audio.utils.numeric module
=======================================

.. automodule:: paddlespeech.audio.utils.numeric
   :members:
   :undoc-members:
   :show-inheritance:
