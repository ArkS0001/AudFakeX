paddlespeech.cli.download module
================================

.. automodule:: paddlespeech.cli.download
   :members:
   :undoc-members:
   :show-inheritance:
