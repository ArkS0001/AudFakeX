paddlespeech.s2t.exps.deepspeech2.bin.deploy.runtime module
===========================================================

.. automodule:: paddlespeech.s2t.exps.deepspeech2.bin.deploy.runtime
   :members:
   :undoc-members:
   :show-inheritance:
