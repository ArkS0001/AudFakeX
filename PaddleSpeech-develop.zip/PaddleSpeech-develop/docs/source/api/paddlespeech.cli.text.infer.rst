paddlespeech.cli.text.infer module
==================================

.. automodule:: paddlespeech.cli.text.infer
   :members:
   :undoc-members:
   :show-inheritance:
