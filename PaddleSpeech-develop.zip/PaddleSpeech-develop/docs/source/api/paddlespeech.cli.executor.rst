paddlespeech.cli.executor module
================================

.. automodule:: paddlespeech.cli.executor
   :members:
   :undoc-members:
   :show-inheritance:
