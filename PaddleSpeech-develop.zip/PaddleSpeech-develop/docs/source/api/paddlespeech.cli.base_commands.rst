paddlespeech.cli.base\_commands module
======================================

.. automodule:: paddlespeech.cli.base_commands
   :members:
   :undoc-members:
   :show-inheritance:
