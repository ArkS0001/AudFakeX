paddlespeech.audio.transform package
====================================

.. automodule:: paddlespeech.audio.transform
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.audio.transform.add_deltas
   paddlespeech.audio.transform.channel_selector
   paddlespeech.audio.transform.cmvn
   paddlespeech.audio.transform.functional
   paddlespeech.audio.transform.perturb
   paddlespeech.audio.transform.spec_augment
   paddlespeech.audio.transform.spectrogram
   paddlespeech.audio.transform.transform_interface
   paddlespeech.audio.transform.transformation
   paddlespeech.audio.transform.wpe
