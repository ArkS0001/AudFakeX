paddlespeech.cli.entry module
=============================

.. automodule:: paddlespeech.cli.entry
   :members:
   :undoc-members:
   :show-inheritance:
