paddlespeech.cls.models.panns package
=====================================

.. automodule:: paddlespeech.cls.models.panns
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.cls.models.panns.classifier
   paddlespeech.cls.models.panns.panns
