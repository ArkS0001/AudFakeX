paddlespeech.cli.asr.infer module
=================================

.. automodule:: paddlespeech.cli.asr.infer
   :members:
   :undoc-members:
   :show-inheritance:
