paddlespeech.kws.models package
===============================

.. automodule:: paddlespeech.kws.models
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.kws.models.loss
   paddlespeech.kws.models.mdtc
