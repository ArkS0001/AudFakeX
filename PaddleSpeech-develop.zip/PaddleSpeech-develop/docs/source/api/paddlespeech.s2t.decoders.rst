paddlespeech.s2t.decoders package
=================================

.. automodule:: paddlespeech.s2t.decoders
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.decoders.beam_search
   paddlespeech.s2t.decoders.ctcdecoder
   paddlespeech.s2t.decoders.scorers

Submodules
----------

.. toctree::
   :maxdepth: 4

   paddlespeech.s2t.decoders.recog
   paddlespeech.s2t.decoders.utils
