paddlespeech.s2t.decoders.scorers.scorer\_interface module
==========================================================

.. automodule:: paddlespeech.s2t.decoders.scorers.scorer_interface
   :members:
   :undoc-members:
   :show-inheritance:
