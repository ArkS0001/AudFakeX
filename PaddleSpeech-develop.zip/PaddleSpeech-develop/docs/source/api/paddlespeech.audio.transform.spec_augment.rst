paddlespeech.audio.transform.spec\_augment module
=================================================

.. automodule:: paddlespeech.audio.transform.spec_augment
   :members:
   :undoc-members:
   :show-inheritance:
