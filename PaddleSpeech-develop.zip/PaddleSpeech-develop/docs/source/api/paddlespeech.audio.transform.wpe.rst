paddlespeech.audio.transform.wpe module
=======================================

.. automodule:: paddlespeech.audio.transform.wpe
   :members:
   :undoc-members:
   :show-inheritance:
